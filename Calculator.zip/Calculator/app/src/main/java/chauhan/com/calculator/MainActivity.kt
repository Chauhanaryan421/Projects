package chauhan.com.calculator

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private var Input : TextView? = null
    var lastnumeric : Boolean = false
    var lastdot : Boolean = false
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Input = findViewById(R.id.Input)
    }
    fun OnDigit(view : View){
        Input?.append((view as Button).text)
        lastnumeric = true
        lastdot = false
    }

    fun OnClear(view:View){
        Input?.text=""
    }
    fun OnDot(view:View){
        if(lastnumeric && !lastdot){
            Input?.append(".")
            lastnumeric = false
            lastdot = true
        }
    }
    fun OnOperator(view: View){
        Input?.text?.let{
            if(lastnumeric && !isOperatorAdded(it.toString())){
                Input?.append((view as Button).text)
                lastnumeric = false
                lastdot = false
            }
        }
    }
    private fun isOperatorAdded(value : String):Boolean{
        return if(value.startsWith("-")){
            false
        }else{
            value.contains("/")||value.contains("+")||value.contains("-")||
                    value.contains("*")
        }
    }
    fun OnEquals(view: View){
        if(lastnumeric){
            var tvValue=Input?.text.toString()
            var prefix = ""
            try{
                if(tvValue.startsWith("-")){
                    prefix = "-"
                    tvValue = tvValue.substring(1)
                }
                if(tvValue.contains("-")) {
                    val SplitValue = tvValue.split("-")
                    var one = SplitValue[0]
                    var two = SplitValue[1]
                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    Input?.text = removeZero((one.toDouble() - two.toDouble()).toString())
                }else if(tvValue.contains("+")) {
                    val SplitValue = tvValue.split("+")
                    var one = SplitValue[0]
                    var two = SplitValue[1]
                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    Input?.text = removeZero((one.toDouble() + two.toDouble()).toString())
                }else if(tvValue.contains("*")) {
                    val SplitValue = tvValue.split("*")
                    var one = SplitValue[0]
                    var two = SplitValue[1]
                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    Input?.text = removeZero((one.toDouble() * two.toDouble()).toString())
                }else if(tvValue.contains("/")) {
                    val SplitValue = tvValue.split("/")
                    var one = SplitValue[0]
                    var two = SplitValue[1]
                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    Input?.text = removeZero((one.toDouble() / two.toDouble()).toString())
                }
            }
            catch(e : ArithmeticException){
                e.printStackTrace()
            }
        }
    }

    private fun removeZero(result : String) : String{
        var value = result
        if (value.contains(".0")){
            value = result.substring(0,result.length-2)
        }
        return value
    }
}